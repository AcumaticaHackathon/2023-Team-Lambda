﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Results;
using System.Web;

using PX.Data;
using PX.Data.Webhooks;
using PX.Objects.CR;
using PX.Objects.PM;
using Newtonsoft.Json;
using System.Collections.Generic;
using PX.Api;
using System.Text;
using System.Xml.Linq;
using System.Linq;
using PX.Data.Wiki.Parser;

namespace Wehhook
{

    public class Record
    {
        public string Origin { get; set; }
        public string Type { get; set; }
        public List<dynamic> Data { get; set; }
    }



    public class IntegrationWebhook : IWebhookHandler
    {

        public async Task<System.Web.Http.IHttpActionResult> ProcessRequestAsync(
          HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var ok = new OkResult(request);
            Dictionary<string, string> notification = new Dictionary<string, string>();
            string origin = "";
            string dataType = "";
            string content = "";
            using (var scope = GetAdminScope())
            {
                content = await request.Content.ReadAsStringAsync();
                notification = JsonConvert.DeserializeObject<Dictionary<string, string>>(content);
                var _queryParameters = HttpUtility.ParseQueryString(request.RequestUri.Query);

                origin = _queryParameters[0];
                dataType = _queryParameters[1];
            }

            PX.Common.PXContext.SetScreenID("SM206015");

            SYProviderMaint graph = PXGraph.CreateInstance<SYProviderMaint>();

            string recordName = origin + "_" + dataType;
            SYProvider provider = new SYProvider
            {
                Name = origin + "_" + dataType,
            };

            provider = graph.Providers.Insert(provider);

            provider.ProviderType = "PX.DataSync.XMLSYProvider";
            graph.Providers.Update(provider);

            foreach (SYProviderParameter param in graph.Parameters.Select())
            {
                switch (param.Name)
                {
                    case "FileName":
                        param.Value = "filename";
                        break;
                    case "Encoding":
                        param.Value = "US-ASCII";
                        break;
                    case "Format":
                        param.Value = "Flat";
                        break;

                }
                graph.Parameters.Update(param);
            }


            graph.Actions.PressSave();

            PX.SM.FileInfo file = AddData(graph.Providers.Cache, graph.Providers.Current, provider.Name, content);

            object t = new object();

            SYProviderParameter param = PXSelect<SYProviderParameter, Where<SYProviderParameter.providerID, Equal<Current<SYProvider.providerID>>,And<SYProviderParameter.name>>.Select(graph);


             graph.Parameters.Cache.RaiseFieldSelecting<SYProviderParameter.value>(graph.Parameters.Current, ref t, true);

            //string extension = file.Name.Substring(Math.Max(0, file.Name.LastIndexOf('.')));
            //string prefix = MimeTypes.GetMimeType(extension).StartsWith("image/") ? "Image:" : "{up}";
            //string WikiLink = "[" + prefix + PXBlockParser.EncodeSpecialChars(file.Name) + "]";

            //foreach (SYProviderParameter param in graph.Parameters.Select())
            //{
            //    switch (param.Name)
            //    {
            //        case "FileName":
            //            param.Value = WikiLink;
            //            break;
            //        case "Encoding":
            //            param.Value = "US-ASCII";
            //            break;
            //        case "Format":
            //            param.Value = "Flat";
            //            break;

            //    }
            //    graph.Parameters.Update(param);
            //}
            //graph.Actions.PressSave();

            graph.FillSchemaFields.Press();
            graph.Actions.PressSave();

            return ok;
        }

        private IDisposable GetAdminScope()
        {
            var userName = "admin";
            if (PXDatabase.Companies.Length > 0)
            {
                var company = PXAccess.GetCompanyName();
                if (string.IsNullOrEmpty(company))
                {
                    company = PXDatabase.Companies[0];
                }
                userName = userName + "@" + company;
            }
            return new PXLoginScope(userName);
        }


        public static PX.SM.FileInfo AddData(PXCache cache, SYProvider provider, string name, string data)
        {
            string xml = MapToXML(data);
            //Build the file name.
            var fileName = name + ".xml";
            //Create xml file
            var file = new PX.SM.FileInfo(fileName, null, Encoding.UTF8.GetBytes(xml));
            //Attach the file
            return AttachFile(cache, provider, file);
        }
        public static PX.SM.FileInfo AttachFile(PXCache sender, SYProvider obj, PX.SM.FileInfo file)
        {
            PX.Common.PXContext.SetScreenID("SM206015");
            var filegraph = PXGraph.CreateInstance<PX.SM.UploadFileMaintenance>();
            if (filegraph.SaveFile(file, PX.SM.FileExistsAction.CreateVersion))
            {

                PXNoteAttribute.AttachFile(sender, obj, file);
                PXDatabase.Insert<NoteDoc>(
                                    new PXDataFieldAssign("NoteID", PXDbType.UniqueIdentifier, obj.NoteID),
                                    new PXDataFieldAssign("FileID", PXDbType.UniqueIdentifier, file.UID));
                
            }
            return file;
        }
        public static string MapToXML(string json)
        {
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
            var xml = new XElement("Root",
                new XElement("Columns",
                    from key in dictionary.Keys select new XElement("Column", new XAttribute("Name", key))
                ),
                new XElement("Rows",
                    new XElement("Row",
                        from key in dictionary.Keys select new XAttribute(key, dictionary[key])
                    )
                )
            );
            return xml.ToString();
        }
    }
}
